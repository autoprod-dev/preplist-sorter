Prepline v3.3.1 - offline version, by Autoprod

How to use
1. Unzip the download (Windows: right-click > Extract All... > Extract).
2. Open the "Prepline" folder and double-click index.html.
   It opens in your web browser (Microsoft Edge or Google Chrome recommended).

It works with no internet connection. Nothing is installed and nothing is sent anywhere:
your files are read inside the browser on this computer. Keep the "lib" folder next to
index.html - the app needs it.

Included third-party software (licence texts in the LICENSES folder):
- pdf.js 5.6.205, Mozilla Foundation, Apache License 2.0 (lib/pdf.min.js, lib/pdf.worker.min.js)
- SheetJS Community Edition (xlsx) 0.18.5, SheetJS LLC, Apache License 2.0 (lib/xlsx.full.min.js)
